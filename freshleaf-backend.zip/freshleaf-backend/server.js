/**
 * FreshLeaf Backend — server.js
 * Main entry point: Express + Socket.io
 */

import 'dotenv/config';
import express from 'express';
import { createServer } from 'http';
import { Server as SocketIO } from 'socket.io';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import connectDB from './config/db.js';

// ── Route imports ──
import authRoutes       from './routes/auth.js';
import productRoutes    from './routes/products.js';
import orderRoutes      from './routes/orders.js';
import offerRoutes      from './routes/offers.js';
import adMediaRoutes    from './routes/adMedia.js';
import ratingRoutes     from './routes/ratings.js';
import notifRoutes      from './routes/notifications.js';
import settingsRoutes   from './routes/settings.js';
import uploadRoutes     from './routes/upload.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ── Connect to MongoDB ──
await connectDB();

const app  = express();
const http = createServer(app);

// ── Socket.io setup (real-time order tracking) ──
export const io = new SocketIO(http, {
  cors: {
    origin: process.env.CLIENT_URL || '*',
    methods: ['GET', 'POST'],
  },
});

io.on('connection', (socket) => {
  console.log(`🔌 Socket connected: ${socket.id}`);

  // Customer joins a room for their order
  socket.on('track_order', (orderId) => {
    socket.join(`order_${orderId}`);
    console.log(`📦 Client tracking order: ${orderId}`);
  });

  socket.on('disconnect', () => {
    console.log(`🔌 Socket disconnected: ${socket.id}`);
  });
});

// ── Middleware ──
app.use(cors({ origin: process.env.CLIENT_URL || '*', credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// ── Serve uploaded files (local storage) ──
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// ── API Routes ──
app.use('/api/auth',          authRoutes);
app.use('/api/products',      productRoutes);
app.use('/api/orders',        orderRoutes);
app.use('/api/offers',        offerRoutes);
app.use('/api/ad-media',      adMediaRoutes);
app.use('/api/ratings',       ratingRoutes);
app.use('/api/notifications', notifRoutes);
app.use('/api/settings',      settingsRoutes);
app.use('/api/upload',        uploadRoutes);

// ── Health check ──
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', app: 'FreshLeaf API', time: new Date().toISOString() });
});

// ── Global error handler ──
app.use((err, _req, res, _next) => {
  console.error(err.stack);
  res.status(err.statusCode || 500).json({
    success: false,
    message: err.message || 'Internal Server Error',
  });
});

const PORT = process.env.PORT || 5000;
http.listen(PORT, () => {
  console.log(`\n🌿 FreshLeaf API running on http://localhost:${PORT}`);
  console.log(`📡 Socket.io enabled for real-time order tracking\n`);
});
