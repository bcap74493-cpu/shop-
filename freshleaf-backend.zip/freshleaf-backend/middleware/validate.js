/**
 * middleware/validate.js
 * Checks express-validator results and returns 422 if invalid.
 */
import { validationResult } from 'express-validator';

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: 'Validation failed',
      errors:  errors.array().map((e) => ({ field: e.path, msg: e.msg })),
    });
  }
  next();
};

export default validate;
