/**
 * controllers/ratingController.js
 */
import { Rating, Notification } from '../models/index.js';
import Order from '../models/Order.js';

export const getRatings = async (_req, res, next) => {
  try {
    const ratings = await Rating.find()
      .populate('customer', 'name')
      .populate('order', '_id')
      .sort({ createdAt: -1 });

    const avg = ratings.length
      ? (ratings.reduce((s, r) => s + r.stars, 0) / ratings.length).toFixed(1)
      : 0;

    res.json({ success: true, count: ratings.length, average: avg, ratings });
  } catch (err) { next(err); }
};

export const getPublicRatings = async (_req, res, next) => {
  try {
    const ratings = await Rating.find()
      .select('custName stars deliveryStars productStars review tags createdAt')
      .sort({ createdAt: -1 })
      .limit(20);

    const avg = ratings.length
      ? (ratings.reduce((s, r) => s + r.stars, 0) / ratings.length).toFixed(1)
      : 0;

    res.json({ success: true, average: avg, ratings });
  } catch (err) { next(err); }
};

export const submitRating = async (req, res, next) => {
  try {
    const { orderId, deliveryStars = 0, productStars = 0, tags = [], review = '' } = req.body;

    // Validate the order belongs to this customer and is delivered
    const order = await Order.findById(orderId);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });
    if (order.status !== 'delivered') {
      return res.status(400).json({ success: false, message: 'Can only rate delivered orders' });
    }

    // Prevent duplicate ratings
    const existing = await Rating.findOne({ order: orderId, customer: req.user._id });
    if (existing) {
      return res.status(409).json({ success: false, message: 'Order already rated' });
    }

    const overall = deliveryStars && productStars
      ? Math.round((deliveryStars + productStars) / 2)
      : deliveryStars || productStars;

    const rating = await Rating.create({
      order:         orderId,
      customer:      req.user._id,
      custName:      req.user.name,
      deliveryStars,
      productStars,
      stars:         overall,
      tags,
      review,
    });

    // Notify owner
    const starStr = '⭐'.repeat(overall);
    await Notification.create({
      recipient:  'owner',
      title:      `${starStr} New Rating from ${req.user.name}`,
      body:       (deliveryStars ? `Delivery: ${deliveryStars}★ ` : '') +
                  (productStars  ? `Product: ${productStars}★`   : '') +
                  (review        ? ` · "${review.slice(0, 60)}"` : ''),
      type:       'rating',
      orderId,
    });

    res.status(201).json({ success: true, rating });
  } catch (err) { next(err); }
};
