/**
 * controllers/notificationController.js
 */
import { Notification } from '../models/index.js';

export const getOwnerNotifs = async (_req, res, next) => {
  try {
    const notifs = await Notification.find({ recipient: 'owner' })
      .sort({ createdAt: -1 }).limit(60);
    const unread = notifs.filter(n => !n.read).length;
    res.json({ success: true, unread, notifs });
  } catch (err) { next(err); }
};

export const getCustNotifs = async (req, res, next) => {
  try {
    const notifs = await Notification.find({
      recipient: 'customer',
      customerId: req.user._id,
    }).sort({ createdAt: -1 }).limit(40);
    const unread = notifs.filter(n => !n.read).length;
    res.json({ success: true, unread, notifs });
  } catch (err) { next(err); }
};

export const markAllRead = async (req, res, next) => {
  try {
    const filter = req.user.role === 'owner'
      ? { recipient: 'owner' }
      : { recipient: 'customer', customerId: req.user._id };
    await Notification.updateMany(filter, { read: true });
    res.json({ success: true, message: 'All marked read' });
  } catch (err) { next(err); }
};

export const markOneRead = async (req, res, next) => {
  try {
    await Notification.findByIdAndUpdate(req.params.id, { read: true });
    res.json({ success: true });
  } catch (err) { next(err); }
};
