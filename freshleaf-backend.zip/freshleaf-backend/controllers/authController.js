/**
 * controllers/authController.js
 */
import User      from '../models/User.js';
import { signToken } from '../middleware/auth.js';

const sendToken = (user, statusCode, res) => {
  const token = signToken(user._id);
  res.status(statusCode).json({
    success: true,
    token,
    user: {
      id:          user._id,
      name:        user.name,
      email:       user.email,
      phone:       user.phone,
      role:        user.role,
      lastAddress: user.lastAddress,
      joinedAt:    user.joinedAt,
    },
  });
};

// POST /api/auth/register
export const register = async (req, res, next) => {
  try {
    const { name, email, password, phone } = req.body;

    if (await User.findOne({ email })) {
      return res.status(409).json({ success: false, message: 'Email already registered' });
    }

    const user = await User.create({ name, email, password, phone, role: 'customer' });
    sendToken(user, 201, res);
  } catch (err) { next(err); }
};

// POST /api/auth/login
export const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email }).select('+password');

    if (!user || !(await user.matchPassword(password))) {
      return res.status(401).json({ success: false, message: 'Invalid email or password' });
    }

    sendToken(user, 200, res);
  } catch (err) { next(err); }
};

// GET /api/auth/me
export const getMe = async (req, res) => {
  res.json({ success: true, user: req.user });
};

// PUT /api/auth/me — update name, phone, lastAddress
export const updateMe = async (req, res, next) => {
  try {
    const { name, phone, lastAddress } = req.body;
    const updated = await User.findByIdAndUpdate(
      req.user._id,
      { name, phone, lastAddress },
      { new: true, runValidators: true }
    );
    res.json({ success: true, user: updated });
  } catch (err) { next(err); }
};

// POST /api/auth/change-password
export const changePassword = async (req, res, next) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id).select('+password');

    if (!(await user.matchPassword(currentPassword))) {
      return res.status(401).json({ success: false, message: 'Current password is incorrect' });
    }
    if (!newPassword || newPassword.length < 6) {
      return res.status(422).json({ success: false, message: 'New password must be at least 6 characters' });
    }

    user.password = newPassword;
    await user.save();
    sendToken(user, 200, res);
  } catch (err) { next(err); }
};
