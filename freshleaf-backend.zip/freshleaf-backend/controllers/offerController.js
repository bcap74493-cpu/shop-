/**
 * controllers/offerController.js
 */
import { Offer } from '../models/index.js';
import Product   from '../models/Product.js';

export const getOffers = async (_req, res, next) => {
  try {
    const offers = await Offer.find({ active: true })
      .populate('product', 'name price image unit category')
      .sort({ createdAt: -1 });
    res.json({ success: true, count: offers.length, offers });
  } catch (err) { next(err); }
};

export const createOffer = async (req, res, next) => {
  try {
    const { product: productId, discount, label } = req.body;

    const product = await Product.findById(productId);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });

    const discPrice = Math.round(product.price * (1 - discount / 100));
    const offer = await Offer.create({
      product: productId,
      discount,
      label:     label || `${discount}% Off`,
      origPrice: product.price,
      discPrice,
    });

    await offer.populate('product', 'name price image unit');
    res.status(201).json({ success: true, offer });
  } catch (err) { next(err); }
};

export const updateOffer = async (req, res, next) => {
  try {
    const offer = await Offer.findByIdAndUpdate(req.params.id, req.body, { new: true })
      .populate('product', 'name price image unit');
    if (!offer) return res.status(404).json({ success: false, message: 'Offer not found' });
    res.json({ success: true, offer });
  } catch (err) { next(err); }
};

export const deleteOffer = async (req, res, next) => {
  try {
    const offer = await Offer.findByIdAndDelete(req.params.id);
    if (!offer) return res.status(404).json({ success: false, message: 'Offer not found' });
    res.json({ success: true, message: 'Offer removed' });
  } catch (err) { next(err); }
};
