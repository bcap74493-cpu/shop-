/**
 * controllers/adMediaController.js
 */
import { AdMedia } from '../models/index.js';

export const getMedia = async (_req, res, next) => {
  try {
    const media = await AdMedia.find({ active: true }).sort({ order: 1, createdAt: 1 });
    res.json({ success: true, count: media.length, media });
  } catch (err) { next(err); }
};

export const addMedia = async (req, res, next) => {
  try {
    const { type, src, caption } = req.body;
    if (!type || !src) {
      return res.status(400).json({ success: false, message: 'type and src are required' });
    }
    const count = await AdMedia.countDocuments({ active: true });
    const item  = await AdMedia.create({ type, src, caption, order: count });
    res.status(201).json({ success: true, media: item });
  } catch (err) { next(err); }
};

export const updateMedia = async (req, res, next) => {
  try {
    const item = await AdMedia.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!item) return res.status(404).json({ success: false, message: 'Media not found' });
    res.json({ success: true, media: item });
  } catch (err) { next(err); }
};

export const deleteMedia = async (req, res, next) => {
  try {
    const item = await AdMedia.findByIdAndUpdate(
      req.params.id, { active: false }, { new: true }
    );
    if (!item) return res.status(404).json({ success: false, message: 'Media not found' });
    res.json({ success: true, message: 'Media removed' });
  } catch (err) { next(err); }
};

// Reorder: body = [{ id, order }]
export const reorderMedia = async (req, res, next) => {
  try {
    const updates = req.body; // [{ id: "...", order: 0 }, ...]
    await Promise.all(
      updates.map(({ id, order }) => AdMedia.findByIdAndUpdate(id, { order }))
    );
    res.json({ success: true, message: 'Media reordered' });
  } catch (err) { next(err); }
};
