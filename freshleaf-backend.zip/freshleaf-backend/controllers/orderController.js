/**
 * controllers/orderController.js
 * Handles order placement, status pipeline, cancellation.
 * Emits Socket.io events and creates Notifications on status change.
 */
import Order   from '../models/Order.js';
import { Notification } from '../models/index.js';
import { io }  from '../server.js';

// ── Helpers ──
const createNotif = (recipient, title, body, type, orderId, customerId = null) =>
  Notification.create({ recipient, title, body, type, orderId, customerId });

// POST /api/orders — place a new order
export const placeOrder = async (req, res, next) => {
  try {
    const { items, address, total, payment } = req.body;

    if (!items?.length || !address || !total) {
      return res.status(400).json({ success: false, message: 'items, address and total are required' });
    }

    const order = await Order.create({
      customer: req.user._id,
      items,
      address,
      total,
      payment: payment || 'cod',
      lat: 20.2961 + (Math.random() - 0.5) * 0.02,
      lng: 85.8245 + (Math.random() - 0.5) * 0.02,
    });

    // Notify owner of new order
    await createNotif(
      'owner',
      `New Order #${order._id.toString().slice(-6)} 🛒`,
      `${items.length} item(s) from ${address.name} · ₹${total}`,
      'order',
      order._id
    );

    // Notify customer
    await createNotif(
      'customer',
      '✅ Order Confirmed!',
      `Your order has been placed. Total: ₹${total}`,
      'order',
      order._id,
      req.user._id
    );

    // Emit socket event to owner room
    io.emit('new_order', { orderId: order._id, customerName: address.name, total });

    res.status(201).json({ success: true, order });
  } catch (err) { next(err); }
};

// GET /api/orders — all orders (owner)
export const getAllOrders = async (_req, res, next) => {
  try {
    const orders = await Order.find()
      .populate('customer', 'name email phone')
      .sort({ createdAt: -1 });
    res.json({ success: true, count: orders.length, orders });
  } catch (err) { next(err); }
};

// GET /api/orders/my — customer's own orders
export const getMyOrders = async (req, res, next) => {
  try {
    const orders = await Order.find({ customer: req.user._id }).sort({ createdAt: -1 });
    res.json({ success: true, orders });
  } catch (err) { next(err); }
};

// GET /api/orders/:id
export const getOrder = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id).populate('customer', 'name email phone');
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    // Customers can only see their own orders
    if (req.user.role !== 'owner' && order.customer?._id.toString() !== req.user._id.toString()) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }
    res.json({ success: true, order });
  } catch (err) { next(err); }
};

// PUT /api/orders/:id/status — owner updates pipeline status
export const updateStatus = async (req, res, next) => {
  try {
    const { status } = req.body;
    const valid = ['confirmed', 'packed', 'out_for_delivery', 'delivered', 'cancelled'];
    if (!valid.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status' });
    }

    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    order.status = status;
    const now = new Date();
    if (status === 'packed')            order.packedAt    = now;
    if (status === 'out_for_delivery')  order.outAt       = now;
    if (status === 'delivered')         order.deliveredAt = now;
    await order.save();

    // Customer notifications
    const custMsgs = {
      packed:           { title: '📦 Order Packed!',       body: `Order is packed and ready!` },
      out_for_delivery: { title: '🛵 Out for Delivery!',   body: `Your order is on its way!` },
      delivered:        { title: '🎉 Order Delivered!',     body: `Your order was delivered. Rate your experience!` },
    };
    if (custMsgs[status] && order.customer) {
      await createNotif('customer', custMsgs[status].title, custMsgs[status].body, status, order._id, order.customer);
    }

    // Push real-time update via Socket.io to the order's room
    io.to(`order_${order._id}`).emit('order_status_update', {
      orderId: order._id,
      status,
      updatedAt: now,
    });

    res.json({ success: true, order });
  } catch (err) { next(err); }
};

// PUT /api/orders/:id/cancel — customer cancels (confirmed only)
export const cancelOrder = async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    // Only the order's customer or the owner can cancel
    const isOwner    = req.user.role === 'owner';
    const isCustomer = order.customer?.toString() === req.user._id.toString();
    if (!isOwner && !isCustomer) {
      return res.status(403).json({ success: false, message: 'Not authorized' });
    }

    // Customers can only cancel when status is 'confirmed'
    if (!isOwner && order.status !== 'confirmed') {
      return res.status(400).json({ success: false, message: 'Cannot cancel — order is already being processed' });
    }
    if (order.status === 'delivered' || order.status === 'cancelled') {
      return res.status(400).json({ success: false, message: 'Order cannot be cancelled' });
    }

    order.status      = 'cancelled';
    order.cancelledAt = new Date();
    order.cancelledBy = isOwner ? 'owner' : 'customer';
    order.cancelReason = req.body.reason || (isOwner ? 'Cancelled by shop' : 'Cancelled by customer');
    await order.save();

    // Notify both parties
    await createNotif('customer', '❌ Order Cancelled', `Order cancelled. Reason: ${order.cancelReason}`, 'cancel', order._id, order.customer);
    if (isCustomer) {
      await createNotif('owner', `Order Cancelled by Customer`, `Customer cancelled order ${order._id.toString().slice(-6)}.`, 'cancel', order._id);
    }

    io.to(`order_${order._id}`).emit('order_status_update', { orderId: order._id, status: 'cancelled' });

    res.json({ success: true, order });
  } catch (err) { next(err); }
};
