/**
 * routes/upload.js
 * POST /api/upload/image  — upload single image (owner only)
 * POST /api/upload/media  — upload image or video (owner only)
 * Returns: { url: "..." }  — URL to use in product.image or adMedia.src
 */
import { Router } from 'express';
import path        from 'path';
import { upload }  from '../config/cloudinary.js';
import { protect, ownerOnly } from '../middleware/auth.js';

const router = Router();
const useCloud = process.env.STORAGE_MODE === 'cloudinary';

// Single image upload
router.post('/image', protect, ownerOnly, upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

  const url = useCloud
    ? req.file.path                                   // Cloudinary returns full URL in path
    : `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;

  res.json({ success: true, url, filename: req.file.filename || req.file.public_id });
});

// Image or video upload (for ad media)
router.post('/media', protect, ownerOnly, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

  const url = useCloud
    ? req.file.path
    : `${req.protocol}://${req.get('host')}/uploads/${req.file.filename}`;

  const mimetype = req.file.mimetype || '';
  const type     = mimetype.startsWith('video') ? 'video' : 'image';

  res.json({ success: true, url, type, filename: req.file.filename || req.file.public_id });
});

export default router;
