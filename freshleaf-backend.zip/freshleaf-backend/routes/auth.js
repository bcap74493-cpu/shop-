/**
 * routes/auth.js
 * POST /api/auth/register  — customer registration
 * POST /api/auth/login     — customer or owner login
 * GET  /api/auth/me        — get current user (protected)
 * PUT  /api/auth/me        — update profile / last address
 * POST /api/auth/change-password — change password (protected)
 */
import { Router } from 'express';
import { body }   from 'express-validator';
import {
  register,
  login,
  getMe,
  updateMe,
  changePassword,
} from '../controllers/authController.js';
import { protect } from '../middleware/auth.js';
import validate    from '../middleware/validate.js';

const router = Router();

router.post(
  '/register',
  [
    body('name').notEmpty().withMessage('Name is required'),
    body('email').isEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 6 }).withMessage('Password min 6 chars'),
  ],
  validate,
  register
);

router.post(
  '/login',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').notEmpty().withMessage('Password required'),
  ],
  validate,
  login
);

router.get('/me', protect, getMe);
router.put('/me', protect, updateMe);
router.post('/change-password', protect, changePassword);

export default router;
