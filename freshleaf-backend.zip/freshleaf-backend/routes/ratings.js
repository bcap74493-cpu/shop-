/**
 * routes/ratings.js
 * GET  /api/ratings           — all ratings (owner)
 * GET  /api/ratings/public    — public ratings summary
 * POST /api/ratings           — submit rating (customer)
 */
import { Router } from 'express';
import { body }   from 'express-validator';
import { getRatings, getPublicRatings, submitRating }
  from '../controllers/ratingController.js';
import { protect, ownerOnly } from '../middleware/auth.js';
import validate from '../middleware/validate.js';

const router = Router();

router.get('/public', getPublicRatings);
router.get('/',       protect, ownerOnly, getRatings);

router.post(
  '/',
  protect,
  [
    body('orderId').notEmpty().withMessage('orderId required'),
    body('deliveryStars').optional().isInt({ min: 0, max: 5 }),
    body('productStars').optional().isInt({ min: 0, max: 5 }),
  ],
  validate,
  submitRating
);

export default router;
