/**
 * routes/products.js
 * GET    /api/products          — list all active products (public)
 * GET    /api/products/:id      — single product (public)
 * POST   /api/products          — create (owner only)
 * PUT    /api/products/:id      — update (owner only)
 * DELETE /api/products/:id      — delete (owner only)
 */
import { Router } from 'express';
import { body }   from 'express-validator';
import {
  getProducts, getProduct,
  createProduct, updateProduct, deleteProduct,
} from '../controllers/productController.js';
import { protect, ownerOnly } from '../middleware/auth.js';
import validate from '../middleware/validate.js';

const router = Router();

router.get('/',    getProducts);
router.get('/:id', getProduct);

router.post(
  '/',
  protect, ownerOnly,
  [
    body('name').notEmpty().withMessage('Product name required'),
    body('price').isNumeric().withMessage('Price must be a number'),
    body('unit').notEmpty().withMessage('Unit required'),
    body('image').notEmpty().withMessage('Image URL required'),
  ],
  validate,
  createProduct
);

router.put('/:id',    protect, ownerOnly, updateProduct);
router.delete('/:id', protect, ownerOnly, deleteProduct);

export default router;
