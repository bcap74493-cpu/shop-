/**
 * routes/settings.js
 * GET  /api/settings     — get settings (public)
 * PUT  /api/settings     — update settings (owner only)
 */
import { Router } from 'express';
import { getSettings, updateSettings } from '../controllers/settingsController.js';
import { protect, ownerOnly } from '../middleware/auth.js';

const router = Router();

router.get('/', getSettings);
router.put('/', protect, ownerOnly, updateSettings);

export default router;
