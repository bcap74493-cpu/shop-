/**
 * routes/notifications.js
 * GET  /api/notifications/owner    — owner notifications (owner only)
 * GET  /api/notifications/customer — customer's notifications
 * PUT  /api/notifications/read-all — mark all read
 * PUT  /api/notifications/:id/read — mark one read
 */
import { Router } from 'express';
import {
  getOwnerNotifs, getCustNotifs, markAllRead, markOneRead,
} from '../controllers/notificationController.js';
import { protect, ownerOnly } from '../middleware/auth.js';

const router = Router();

router.get('/owner',      protect, ownerOnly, getOwnerNotifs);
router.get('/customer',   protect,            getCustNotifs);
router.put('/read-all',   protect,            markAllRead);
router.put('/:id/read',   protect,            markOneRead);

export default router;
