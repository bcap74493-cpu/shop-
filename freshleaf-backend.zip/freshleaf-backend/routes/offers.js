/**
 * routes/offers.js
 * GET    /api/offers        — all active offers (public)
 * POST   /api/offers        — create offer (owner)
 * PUT    /api/offers/:id    — update offer (owner)
 * DELETE /api/offers/:id    — delete offer (owner)
 */
import { Router } from 'express';
import { body }   from 'express-validator';
import {
  getOffers, createOffer, updateOffer, deleteOffer,
} from '../controllers/offerController.js';
import { protect, ownerOnly } from '../middleware/auth.js';
import validate from '../middleware/validate.js';

const router = Router();

router.get('/', getOffers);

router.post(
  '/',
  protect, ownerOnly,
  [
    body('product').notEmpty().withMessage('Product ID required'),
    body('discount').isFloat({ min: 1, max: 95 }).withMessage('Discount 1–95% required'),
  ],
  validate,
  createOffer
);

router.put('/:id',    protect, ownerOnly, updateOffer);
router.delete('/:id', protect, ownerOnly, deleteOffer);

export default router;
