/**
 * routes/adMedia.js
 * GET    /api/ad-media        — all active media (public)
 * POST   /api/ad-media        — add media slot (owner)
 * PUT    /api/ad-media/:id    — update caption / order (owner)
 * DELETE /api/ad-media/:id    — remove slot (owner)
 * PUT    /api/ad-media/reorder — reorder slots (owner)
 */
import { Router } from 'express';
import { getMedia, addMedia, updateMedia, deleteMedia, reorderMedia }
  from '../controllers/adMediaController.js';
import { protect, ownerOnly } from '../middleware/auth.js';

const router = Router();

router.get('/',           getMedia);
router.post('/',          protect, ownerOnly, addMedia);
router.put('/reorder',    protect, ownerOnly, reorderMedia);
router.put('/:id',        protect, ownerOnly, updateMedia);
router.delete('/:id',     protect, ownerOnly, deleteMedia);

export default router;
