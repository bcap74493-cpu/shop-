/**
 * routes/orders.js
 * POST   /api/orders             — place order (customer)
 * GET    /api/orders             — all orders (owner)
 * GET    /api/orders/my          — customer's own orders
 * GET    /api/orders/:id         — single order
 * PUT    /api/orders/:id/status  — update status (owner)
 * PUT    /api/orders/:id/cancel  — cancel order (customer, confirmed only)
 */
import { Router } from 'express';
import {
  placeOrder, getAllOrders, getMyOrders,
  getOrder, updateStatus, cancelOrder,
} from '../controllers/orderController.js';
import { protect, ownerOnly } from '../middleware/auth.js';

const router = Router();

router.post('/',                protect,              placeOrder);
router.get('/',                 protect, ownerOnly,   getAllOrders);
router.get('/my',               protect,              getMyOrders);
router.get('/:id',              protect,              getOrder);
router.put('/:id/status',       protect, ownerOnly,   updateStatus);
router.put('/:id/cancel',       protect,              cancelOrder);

export default router;
