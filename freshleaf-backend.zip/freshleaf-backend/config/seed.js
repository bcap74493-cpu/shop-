/**
 * config/seed.js — Seeds default owner account + initial settings
 * Run: node config/seed.js
 */
import 'dotenv/config';
import connectDB from './db.js';
import User     from '../models/User.js';
import Settings from '../models/Settings.js';

await connectDB();

// ── Seed owner ──
const existing = await User.findOne({ role: 'owner' });
if (existing) {
  console.log('✅ Owner account already exists:', existing.email);
} else {
  const owner = await User.create({
    name:     process.env.OWNER_NAME     || 'Shop Owner',
    email:    process.env.OWNER_EMAIL    || 'owner@freshleaf.com',
    password: process.env.OWNER_PASSWORD || 'owner123',
    phone:    '',
    role:     'owner',
  });
  console.log('✅ Owner account created:', owner.email);
}

// ── Seed default settings ──
const settingsExist = await Settings.findOne();
if (!settingsExist) {
  await Settings.create({
    shopName:         'FreshLeaf',
    tagline:          'Farm fresh, delivered fast',
    logoEmoji:        '🌿',
    heroTitle:        'Farm-Fresh {em} & Fruits — Delivered Daily',
    heroEm:           'Vegetables',
    heroSubtitle:     'Locally sourced, handpicked produce at your doorstep.',
    heroDeco:         '🥦',
    shopSectionTitle: 'Fresh Today 🥕',
    colorDark:        '#1a3a1f',
    colorMid:         '#2d6a35',
    colorLime:        '#a8d82b',
    deliveryFee:      30,
    freeDeliveryAbove:300,
    currency:         '₹',
    deliveryTime:     '20-35 minutes',
  });
  console.log('✅ Default settings created');
}

console.log('\n🌿 Seed complete. Start the server with: node server.js\n');
process.exit(0);
