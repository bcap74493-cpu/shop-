/**
 * config/cloudinary.js
 * Configures Cloudinary + multer for image/video uploads.
 * Set STORAGE_MODE=cloudinary in .env for production.
 * Set STORAGE_MODE=local  for local disk storage (demo).
 */
import { v2 as cloudinary } from 'cloudinary';
import { CloudinaryStorage } from 'multer-storage-cloudinary';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key:    process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// ── Choose storage based on env ──
const useCloud = process.env.STORAGE_MODE === 'cloudinary';

const cloudStorage = new CloudinaryStorage({
  cloudinary,
  params: {
    folder:         'freshleaf',
    allowed_formats: ['jpg', 'jpeg', 'png', 'webp', 'mp4', 'mov'],
    resource_type:  'auto',
  },
});

const diskStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, path.join(__dirname, '../uploads'));
  },
  filename: (_req, file, cb) => {
    const unique = `${Date.now()}-${Math.round(Math.random() * 1e9)}`;
    cb(null, unique + path.extname(file.originalname));
  },
});

const fileFilter = (_req, file, cb) => {
  const allowed = /jpeg|jpg|png|webp|mp4|mov/;
  const ext = allowed.test(path.extname(file.originalname).toLowerCase());
  const mime = allowed.test(file.mimetype);
  if (ext && mime) cb(null, true);
  else cb(new Error('Only images (jpg, png, webp) and videos (mp4, mov) are allowed'));
};

export const upload = multer({
  storage:   useCloud ? cloudStorage : diskStorage,
  fileFilter,
  limits: { fileSize: 50 * 1024 * 1024 }, // 50 MB max
});

export { cloudinary };
