/**
 * models/User.js
 * Covers both customers and the owner (role field).
 */
import mongoose from 'mongoose';
import bcrypt   from 'bcryptjs';

const userSchema = new mongoose.Schema(
  {
    name:  { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    phone: { type: String, default: '' },
    password: { type: String, required: true, minlength: 6, select: false },
    role:  { type: String, enum: ['customer', 'owner'], default: 'customer' },

    // Customer-specific: last delivery address for auto-fill
    lastAddress: {
      name:    String,
      phone:   String,
      pin:     String,
      area:    String,
      address: String,
      city:    String,
    },

    joinedAt: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// ── Hash password before save ──
userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(12);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// ── Compare password ──
userSchema.methods.matchPassword = async function (plain) {
  return bcrypt.compare(plain, this.password);
};

export default mongoose.model('User', userSchema);
