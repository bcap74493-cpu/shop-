/**
 * models/Product.js
 */
import mongoose from 'mongoose';

const productSchema = new mongoose.Schema(
  {
    name:     { type: String, required: true, trim: true },
    price:    { type: Number, required: true, min: 0 },
    unit:     { type: String, required: true, default: 'per kg' },
    category: { type: String, required: true, default: 'Vegetables' },
    image:    { type: String, required: true },  // URL (local path or Cloudinary URL)
    stock:    { type: Number, default: null },     // null = unlimited
    active:   { type: Boolean, default: true },
  },
  { timestamps: true }
);

export default mongoose.model('Product', productSchema);
