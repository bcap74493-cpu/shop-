/**
 * models/Offer.js
 */
import mongoose from 'mongoose';

const offerSchema = new mongoose.Schema({
  product:    { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  discount:   { type: Number, required: true, min: 1, max: 95 },
  label:      { type: String, default: '' },
  origPrice:  Number,
  discPrice:  Number,
  active:     { type: Boolean, default: true },
}, { timestamps: true });

export const Offer = mongoose.model('Offer', offerSchema);

// ──────────────────────────────────────────────────

/**
 * models/AdMedia.js
 */
const adMediaSchema = new mongoose.Schema({
  type:     { type: String, enum: ['image', 'video'], required: true },
  src:      { type: String, required: true },  // URL
  caption:  { type: String, default: '' },
  order:    { type: Number, default: 0 },
  active:   { type: Boolean, default: true },
}, { timestamps: true });

export const AdMedia = mongoose.model('AdMedia', adMediaSchema);

// ──────────────────────────────────────────────────

/**
 * models/Rating.js
 */
const ratingSchema = new mongoose.Schema({
  order:         { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
  customer:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  custName:      { type: String, default: 'Customer' },
  deliveryStars: { type: Number, min: 0, max: 5, default: 0 },
  productStars:  { type: Number, min: 0, max: 5, default: 0 },
  stars:         { type: Number, min: 0, max: 5 },  // overall average
  tags:          [String],
  review:        { type: String, default: '' },
}, { timestamps: true });

export const Rating = mongoose.model('Rating', ratingSchema);

// ──────────────────────────────────────────────────

/**
 * models/Notification.js
 */
const notifSchema = new mongoose.Schema({
  recipient:  { type: String, enum: ['owner', 'customer'], required: true },
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  title:      { type: String, required: true },
  body:       { type: String, default: '' },
  type:       { type: String, default: 'order' },
  orderId:    { type: mongoose.Schema.Types.ObjectId, ref: 'Order', default: null },
  read:       { type: Boolean, default: false },
}, { timestamps: true });

export const Notification = mongoose.model('Notification', notifSchema);

// ──────────────────────────────────────────────────

/**
 * models/Settings.js
 * Single document — always upserted.
 */
const settingsSchema = new mongoose.Schema({
  shopName:          { type: String, default: 'FreshLeaf' },
  tagline:           { type: String, default: 'Farm fresh, delivered fast' },
  logoEmoji:         { type: String, default: '🌿' },
  heroTitle:         { type: String, default: 'Farm-Fresh {em} & Fruits — Delivered Daily' },
  heroEm:            { type: String, default: 'Vegetables' },
  heroSubtitle:      { type: String, default: 'Locally sourced, handpicked produce at your doorstep.' },
  heroDeco:          { type: String, default: '🥦' },
  shopSectionTitle:  { type: String, default: 'Fresh Today 🥕' },
  colorDark:         { type: String, default: '#1a3a1f' },
  colorMid:          { type: String, default: '#2d6a35' },
  colorLime:         { type: String, default: '#a8d82b' },
  deliveryFee:       { type: Number, default: 30 },
  freeDeliveryAbove: { type: Number, default: 300 },
  currency:          { type: String, default: '₹' },
  deliveryTime:      { type: String, default: '20-35 minutes' },
  phone:             { type: String, default: '' },
  whatsapp:          { type: String, default: '' },
  email:             { type: String, default: '' },
  address:           { type: String, default: '' },
  hours:             { type: String, default: '' },
  instagram:         { type: String, default: '' },
  facebook:          { type: String, default: '' },
  website:           { type: String, default: '' },
  announcement:      { type: String, default: '' },
  bannerColor:       { type: String, default: '#a8d82b' },
  bannerVisible:     { type: String, enum: ['show', 'hide'], default: 'hide' },
}, { timestamps: true });

export const Settings = mongoose.model('Settings', settingsSchema);
export default Settings;
