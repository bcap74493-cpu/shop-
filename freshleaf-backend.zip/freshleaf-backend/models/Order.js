/**
 * models/Order.js
 */
import mongoose from 'mongoose';

const orderItemSchema = new mongoose.Schema({
  product:   { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  name:      String,
  price:     Number,
  origPrice: Number,
  qty:       Number,
  image:     String,
}, { _id: false });

const addressSchema = new mongoose.Schema({
  name:    String,
  phone:   String,
  pin:     String,
  area:    String,
  address: String,
  city:    String,
}, { _id: false });

const orderSchema = new mongoose.Schema(
  {
    customer:  { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    items:     [orderItemSchema],
    address:   addressSchema,
    total:     { type: Number, required: true },
    payment:   { type: String, enum: ['cod', 'upi'], default: 'cod' },

    // Pipeline status
    status: {
      type:    String,
      enum:    ['confirmed', 'packed', 'out_for_delivery', 'delivered', 'cancelled'],
      default: 'confirmed',
    },

    // Timestamps for each pipeline step
    packedAt:     { type: Date, default: null },
    outAt:        { type: Date, default: null },
    deliveredAt:  { type: Date, default: null },
    cancelledAt:  { type: Date, default: null },

    cancelledBy:  { type: String, enum: ['customer', 'owner'], default: null },
    cancelReason: { type: String, default: null },

    // Delivery coordinates (for map)
    lat: { type: Number, default: 20.2961 },
    lng: { type: Number, default: 85.8245 },
  },
  { timestamps: true }
);

export default mongoose.model('Order', orderSchema);
